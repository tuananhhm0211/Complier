# How to run
- Go to the folder containing the lexer and parser folders
- Starting file is `main.py`.
```py
if __name__ == '__main__':
    file = "{input_file_name}"
    ...
```
- Put `{input_file_name}.vc` into the `file` variable in `main.py` function
- In terminal enter `python main.py`