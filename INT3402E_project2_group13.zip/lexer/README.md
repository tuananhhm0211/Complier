# How to run
- Starting file is `main.py`.
```py
if __name__ == '__main__':
    generate_token("{input_file_name}")
```
- Put `{input_file_name}.vc` file in the same directory as `main.py` and put file name in `generate_token` function.
- Run the `main.py` file.